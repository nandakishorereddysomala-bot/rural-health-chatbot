(function () {
  "use strict";

  var chatEl = document.getElementById("chat");
  var inputEl = document.getElementById("messageInput");
  var sendBtn = document.getElementById("sendBtn");
  var resetBtn = document.getElementById("resetBtn");

  var SAMPLE_PROMPTS = [
    "I have fever and headache",
    "Tell me about malaria",
    "I have cough for many weeks",
    "burning while urinating",
  ];

  function addBubble(text, who) {
    var el = document.createElement("div");
    el.className = "msg " + who;
    el.textContent = text;
    chatEl.appendChild(el);
    scrollDown();
    return el;
  }

  function addQuickReplies(prompts) {
    var row = document.createElement("div");
    row.className = "quick-replies";
    prompts.forEach(function (p) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.textContent = p;
      btn.addEventListener("click", function () {
        send(p);
      });
      row.appendChild(btn);
    });
    chatEl.appendChild(row);
    scrollDown();
  }

  function scrollDown() {
    chatEl.scrollTop = chatEl.scrollHeight;
  }

  function renderReplies(replies, isFirst) {
    replies.forEach(function (r) {
      if (r.kind === "options") {
        addQuickReplies(r.options);
      } else {
        addBubble(r.text, "bot");
      }
    });
    if (isFirst) {
      addQuickReplies(SAMPLE_PROMPTS);
    }
  }

  function startChat() {
    chatEl.innerHTML = "";
    addBubble("Please wait...", "bot");
    fetch("/api/start")
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        chatEl.innerHTML = "";
        renderReplies(data.replies, true);
      })
      .catch(function () {
        chatEl.innerHTML = "";
        addBubble(
          "Could not reach the chatbot server. Please try again.",
          "bot"
        );
      });
  }

  function send(text) {
    var value = (text || inputEl.value).trim();
    if (!value) {
      return;
    }
    inputEl.value = "";
    addBubble(value, "user");
    var typing = document.createElement("div");
    typing.className = "typing";
    typing.textContent = "Bot is typing...";
    chatEl.appendChild(typing);
    scrollDown();

    fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: value }),
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (typing.parentNode) {
          typing.parentNode.removeChild(typing);
        }
        renderReplies(data.replies, false);
      })
      .catch(function () {
        if (typing.parentNode) {
          typing.parentNode.removeChild(typing);
        }
        addBubble("Something went wrong. Please try again.", "bot");
      });
  }

  sendBtn.addEventListener("click", function () {
    send();
  });

  inputEl.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      send();
      e.preventDefault();
    }
  });

  resetBtn.addEventListener("click", function () {
    fetch("/api/reset", { method: "POST" })
      .then(startChat)
      .catch(startChat);
  });

  startChat();
})();