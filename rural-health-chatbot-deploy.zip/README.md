# Rural Health Chatbot

A simple, offline-friendly web chatbot for rural health. The user types a
**symptom** and the bot asks a few yes/no questions, then suggests the most
likely disease with medicines, precautions, diet and doctor advice. The user
can also type a **disease name** and the bot asks confirmation questions and
gives management suggestions.

> This is an EDUCATIONAL sample. It is not a real doctor and cannot replace
> professional medical care. Every answer includes a disclaimer.

## Features

- Symptom → disease diagnosis flow with clarifying questions
- Disease → guidance flow with symptom confirmation
- Built-in knowledge base of common rural health problems (fever, malaria,
  dengue, typhoid, TB, acidity, anaemia, diabetes, BP, UTI, eye infection,
  skin fungus, chicken pox and more)
- Responsive web UI built for both desktop and mobile phones
- No database needed; conversation state is kept in the browser session

## Files

```
diseases.py          Knowledge base (editable): diseases, symptoms,
                     questions, medicines, precautions, diet
chatbot.py           Conversation engine (symptom matching + flows)
app.py               Flask web server + chat API
templates/index.html Chat page
static/style.css     Responsive styling
static/script.js     Chat UI logic
```

## How to run

1. Install Python 3.9+ if not already installed.
2. Install Flask:

   ```bash
   pip install -r requirements.txt
   ```

3. Start the server:

   ```bash
   python app.py
   ```

4. Open your browser at <http://127.0.0.1:5000>

On a phone on the same Wi-Fi network, open `http://<your-pc-ip>:5000`
(find the IP with `ipconfig`). The page is mobile-friendly.

## How to use / demo

- "I have fever and headache" → bot asks questions, then diagnoses
- "Tell me about malaria" or just "malaria" → bot asks questions, then gives suggestions
- Answer with **yes** / **no** for the bot's questions
- "help" shows usage tips
- "Start over" resets the conversation

## Adding or editing diseases

Open `diseases.py`. Each disease has:

- `symptoms`: list of `(symptom phrase, weight)` — weight 2 = strong sign
- `medicines`: first-aid / home-care suggestions
- `precautions`, `diet`, `when_doctor`: display sections

Also add any new user words in `SYMPTOM_ALIASES` (user phrasing → canonical
symptom) and optionally a disease name in `DISEASE_ALIASES`.

## API

- `GET /api/start` — conversation greeting
- `POST /api/chat` — send `{"message": "..."}`, get `{"replies": [...]}`
- `POST /api/reset` — clear conversation state