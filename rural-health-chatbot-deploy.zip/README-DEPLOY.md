# Deploy the Rural Health Chatbot to the web (free)

This is a step-by-step guide to publish the chatbot on the internet for free
using **GitHub** (repo hosting) + **Render** (free web hosting).

> Your laptop has no `git` installed, so this guide uses the **web browser**
> to upload files instead of the git command line.

---

## Step 1 — Create a GitHub account (5 minutes)

1. Go to <https://github.com/signup> and create a free account.
2. Remember your username and password. Confirm your email.

## Step 2 — Create a repository and upload the project files

1. After login, click the **+** sign (top right) -> **New repository**.
2. Name it: `rural-health-chatbot` (any name is fine). Keep it **Public**
   (free). Do NOT tick "Add a README". Click **Create repository**.
3. On the new empty repo page click **uploading an existing file**.
4. Upload the file called `rural-health-chatbot.zip` from the project folder
   (it already contains the whole project). Click **Commit changes**.
5. The files are now in your repo.

> Note: GitHub lets you upload a zip in the browser and it stores the files
> inside it. If the zip upload gives trouble, instead drag-and-drop the
> individual files: `app.py`, `chatbot.py`, `diseases.py`, `requirements.txt`,
> `render.yaml`, `.gitignore`, plus the `templates/` and `static/` folders
> (which is a few extra clicks but also works).

## Step 3 — Create the free Render service (2 minutes)

1. Go to <https://render.com> and click **Get Started** -> sign up with your
   **GitHub** account (this is what lets Render read your repo).
2. After signup, open the dashboard and click **New +** -> **Blueprint**.
   (Selecting any repo with a `render.yaml` file shows "Blueprints".)
3. Select your `rural-health-chatbot` repo. Render reads `render.yaml`,
   chooses the **free plan**, and creates the web service automatically.
4. Wait ~5 minutes for the first build. When the status turns **Live**,
   your app is up.

## Step 4 — Get your link

1. In Render, open your service `rural-health-chatbot`.
2. The URL is shown on top, in the format:
   `https://rural-health-chatbot.onrender.com`
   (the exact name may be different if it was taken).
3. Open that link on any computer or phone — that is your chatbot.

---

### Important notes

- **Free plan sleeps**: after ~15 minutes of no visitors the site sleeps.
  The first visit after a break takes about a minute to wake up. Totally
  normal.
- **Keep the code updated**: edit files locally, re-upload to GitHub, and
  Render rebuilds automatically.
- **Your data**: the chatbot keeps conversation state only in the browser
  session, so no database is needed.

### If something fails

- Service shows a build error: open the service -> **Events** tab -> read the
  last error and screenshot/forward it.
- Blank page: wait 1 minute on the page (waking up).
- Email animation from Render asking to confirm your account — do it, or the
  service will be paused.